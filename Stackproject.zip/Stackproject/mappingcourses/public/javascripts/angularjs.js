var app=angular.module('Myapp',[]);
app.controller('myCtrl',function($scope,$http){
	//document format if square brakects are represented as array
	$scope.student={}
	$scope.studentdata=[]
	$scope.loginform=function(val){
		$http({
			method:'post',
			url:'/checkdata',
			data:val
		}).then(function(success){
			console.log(success)
			if(success.data==''){
				alert("some Credentials wrong")
			}else{
					location.href="/courses"
					alert("login success")
					
			}
		},function(err){
			console.log(err);
			alert("incorrect data")
		})
	}
	$scope.upd={}
	$scope.upddata=[]
	$scope.registration=function(val){
		$http({
			method:'post',
			url:'/senddata',
			data: val
		}).then(function(success){
			console.log(success);
			alert("successfully submitted");
			},function(err){
				console.log(err);
			})
	}
	$scope.get1=function(){
		$http({
			method:'get',
			url:'/getdata',
		}).then(function(success){
			console.log(success);
			$scope.upddata=success.data
		},function(err){
			console.log(err);
		})
	}
	$scope.Update=function(val){
		$http({
			method:'post',
			url:'/post1',
			data:val
		}).then(function(sucess){
			console.log(success);
		},function(err){
			console.log(err);
		})
	}
});
